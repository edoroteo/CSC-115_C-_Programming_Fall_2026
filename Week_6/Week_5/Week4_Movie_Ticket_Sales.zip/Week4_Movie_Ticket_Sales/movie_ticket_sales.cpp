// Movie Theater Ticket Sales System


#include <iostream>
#include <iomanip>
#include <limits>
#include <cmath>
using namespace std;

int main()
{
    // Ticket prices
    const double CHILD_PRICE = 8.00;
    const double ADULT_PRICE = 12.00;
    const double SENIOR_PRICE = 9.00;

    char again = 'Y';   // controls the sales session loop

    // Show money with 2 decimal places
    cout << fixed << setprecision(2);

    // Loop that repeats the whole sales session
    while (again == 'Y' || again == 'y')
    {
        // Counters and accumulators
        int totalTickets = 0;
        int childTickets = 0;
        int adultTickets = 0;
        int seniorTickets = 0;
        double totalRevenue = 0.0;

        int numCustomers;

        //Ask number of customers and validate
        cout << "Enter the number of customers (1-50): ";
        cin >> numCustomers;

        while (cin.fail() || numCustomers < 1 || numCustomers > 50)
        {
            if (cin.fail())
            {
                cin.clear();                                         // clear error
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // throw away bad input
            }
            cout << "Invalid number. Please enter a value between 1 and 50." << endl;
            cout << endl;
            cout << "Enter the number of customers (1-50): ";
            cin >> numCustomers;
        }

        //Process each customer
        for (int customer = 1; customer <= numCustomers; customer++)
        {
            int quantity;
            int choice;
            double price = 0.0;
            string category;

            cout << endl;
            cout << "Customer " << customer << endl;
            cout << "------------------------------" << endl;

            // Ask for number of tickets and validate
            cout << "How many tickets would you like to purchase (1-10)? ";
            cin >> quantity;

            while (cin.fail() || quantity < 1 || quantity > 10)
            {
                if (cin.fail())
                {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
                cout << "Invalid quantity. Please enter a value between 1 and 10." << endl;
                cout << endl;
                cout << "How many tickets would you like to purchase (1-10)? ";
                cin >> quantity;
            }

            // Show the category menu
            cout << endl;
            cout << "Select Ticket Category" << endl;
            cout << "1. Child - $" << CHILD_PRICE << endl;
            cout << "2. Adult - $" << ADULT_PRICE << endl;
            cout << "3. Senior - $" << SENIOR_PRICE << endl;
            cout << endl;

            // Ask for category and validate
            cout << "Enter your selection: ";
            cin >> choice;

            while (cin.fail() || choice < 1 || choice > 3)
            {
                if (cin.fail())
                {
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
                cout << "Invalid selection. Please choose 1, 2, or 3." << endl;
                cout << endl;
                cout << "Enter your selection: ";
                cin >> choice;
            }

            // Set the price and update the category counter
            if (choice == 1)
            {
                category = "Child";
                price = CHILD_PRICE;
                childTickets = childTickets + quantity;
            }
            else if (choice == 2)
            {
                category = "Adult";
                price = ADULT_PRICE;
                adultTickets = adultTickets + quantity;
            }
            else
            {
                category = "Senior";
                price = SENIOR_PRICE;
                seniorTickets = seniorTickets + quantity;
            }

            // Calculate the transaction total
            double transactionTotal = quantity * price;

            // Update accumulators
            totalTickets = totalTickets + quantity;
            totalRevenue = totalRevenue + transactionTotal;

            // Show the transaction
            cout << endl;
            cout << "Tickets Purchased: " << quantity << endl;
            cout << "Ticket Category: " << category << endl;
            cout << "Price Per Ticket: $" << price << endl;
            cout << "Transaction Total: $" << transactionTotal << endl;
        }

        //Calculate average transaction
        double averageTransaction = totalRevenue / numCustomers;

        //Display the sales report
        cout << endl;
        cout << "========================================" << endl;
        cout << "       MOVIE THEATER SALES REPORT" << endl;
        cout << "========================================" << endl;
        cout << "Customers Processed:       " << numCustomers << endl;
        cout << endl;
        cout << "Child Tickets Sold:        " << childTickets << endl;
        cout << "Adult Tickets Sold:        " << adultTickets << endl;
        cout << "Senior Tickets Sold:       " << seniorTickets << endl;
        cout << endl;
        cout << "Total Tickets Sold:        " << totalTickets << endl;
        cout << "Total Revenue:             $" << totalRevenue << endl;
        cout << "Average Transaction:       $" << averageTransaction << endl;
        cout << "========================================" << endl;

        //Ask if the user wants another session
        cout << endl;
        cout << "Would you like to process another sales session?" << endl;
        cout << "Enter Y for Yes or N for No: ";
        cin >> again;

        while (again != 'Y' && again != 'y' && again != 'N' && again != 'n')
        {
            cout << "Invalid choice. Please enter Y or N." << endl;
            cout << endl;
            cout << "Enter Y for Yes or N for No: ";
            cin >> again;
        }

        cout << endl;
    }

    cout << "Thank you for using the Movie Theater Ticket Sales System. Goodbye!" << endl;

    return 0;
}
