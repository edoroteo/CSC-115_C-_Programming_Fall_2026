// course_grades_2.cpp
// Week 4 Assignment: Course Grades and Average with Menu

#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

const int MAX_COURSES = 20;

// ----- Function prototypes -----
void displayMenu();
int enterCourses(string courseIds[], double grades[]);
double getValidGrade();
void displaySpecificCourse(string courseIds[], double grades[], int numCourses);
void displayAllCourses(string courseIds[], double grades[], int numCourses);
double calculateAverage(double grades[], int numCourses);
string getLetterGrade(double average);
void displayAverage(double grades[], int numCourses);

int main()
{
    string courseIds[MAX_COURSES];   // course IDs entered by the user
    double grades[MAX_COURSES];      // grades for each course
    int numCourses = 0;              // how many courses have been entered
    int choice = 0;

    // Format all decimal numbers with 2 digits after the decimal point
    cout << fixed << setprecision(2);

    // Menu loop
    do
    {
        displayMenu();
        cout << "Enter your choice (1-5): ";
        cin >> choice;

        // If the user typed something that is not a number
        if (cin.fail())
        {
            cin.clear();
            cin.ignore(1000, '\n');
            choice = 0;
        }
        cout << endl;

        // Switch-case statement
        switch (choice)
        {
        case 1:
            numCourses = enterCourses(courseIds, grades);
            break;
        case 2:
            displaySpecificCourse(courseIds, grades, numCourses);
            break;
        case 3:
            displayAllCourses(courseIds, grades, numCourses);
            break;
        case 4:
            displayAverage(grades, numCourses);
            break;
        case 5:
            cout << "Goodbye!" << endl;
            break;
        default:
            cout << "Invalid choice. Please enter 1 to 5." << endl;
        }
        cout << endl;
    } while (choice != 5);

    return 0;
}

// Display the menu
void displayMenu()
{
    cout << "Course Grades Menu" << endl;
    cout << "------------------" << endl;
    cout << "1. Enter Number of Courses" << endl;
    cout << "2. Display a Specific Course and Grade" << endl;
    cout << "3. Display All Courses and Grades" << endl;
    cout << "4. Display Overall Average and Letter Grade" << endl;
    cout << "5. Exit" << endl;
}

// Option 1: get number of courses, then each ID and grade
// Returns the number of courses entered
int enterCourses(string courseIds[], double grades[])
{
    int numCourses;

    // Input validation
    do
    {
        cout << "How many courses (1-20)? ";
        cin >> numCourses;
        if (cin.fail() || numCourses < 1 || numCourses > MAX_COURSES)
        {
            cout << "Invalid number. Enter a number from 1 to 20." << endl;
            cin.clear();
            cin.ignore(1000, '\n');
            numCourses = 0;
        }
    } while (numCourses < 1);

    // Loop to read each course ID and grade
    for (int i = 0; i < numCourses; i++)
    {
        cout << endl;
        cout << "Course " << (i + 1) << " ID: ";
        cin >> courseIds[i];
        grades[i] = getValidGrade();
    }

    cout << endl;
    cout << "All courses entered." << endl;
    return numCourses;
}

//Reads a grade and makes sure it is between 0 and 100
double getValidGrade()
{
    double grade;

    do
    {
        cout << "Grade: ";
        cin >> grade;
        if (cin.fail() || grade < 0 || grade > 100)
        {
            cout << "Invalid grade. Enter a number from 0 to 100." << endl;
            cin.clear();
            cin.ignore(1000, '\n');
            grade = -1;
        }
    } while (grade < 0);

    return grade;
}

//Option 2: search for one course and display it
void displaySpecificCourse(string courseIds[], double grades[], int numCourses)
{
    if (numCourses == 0)
    {
        cout << "No courses entered yet. Choose option 1 first." << endl;
        return;
    }

    string searchId;
    bool found = false;

    cout << "Enter the course ID to find: ";
    cin >> searchId;

    // Loop through the courses looking for a match
    for (int i = 0; i < numCourses; i++)
    {
        if (courseIds[i] == searchId)
        {
            cout << courseIds[i] << ": " << grades[i] << endl;
            found = true;
        }
    }

    if (!found)
    {
        cout << "Course " << searchId << " was not found." << endl;
    }
}

//Option 3: display all courses and grades
void displayAllCourses(string courseIds[], double grades[], int numCourses)
{
    if (numCourses == 0)
    {
        cout << "No courses entered yet. Choose option 1 first." << endl;
        return;
    }

    cout << "Course Grades" << endl;
    cout << "-------------" << endl;
    for (int i = 0; i < numCourses; i++)
    {
        cout << left << setw(12) << courseIds[i]
             << right << setw(7) << grades[i] << endl;
    }
}

//Calculate the average of the courses
double calculateAverage(double grades[], int numCourses)
{
    double total = 0.0;

    for (int i = 0; i < numCourses; i++)
    {
        total += grades[i];
    }

    return total / numCourses;
}

//Grading scale
string getLetterGrade(double average)
{
    if (average >= 94)
        return "A";
    else if (average >= 90)
        return "A-";
    else if (average >= 86)
        return "B+";
    else if (average >= 83)
        return "B";
    else if (average >= 79)
        return "B-";
    else if (average >= 75)
        return "C+";
    else if (average >= 70)
        return "C";
    else if (average >= 66)
        return "C-";
    else
        return "F";
}

//Option 4: display overall average and letter grade
void displayAverage(double grades[], int numCourses)
{
    if (numCourses == 0)
    {
        cout << "No courses entered yet. Choose option 1 first." << endl;
        return;
    }

    double average = calculateAverage(grades, numCourses);
    cout << "Average Grade: " << average << endl;
    cout << "Letter Grade: " << getLetterGrade(average) << endl;
}
