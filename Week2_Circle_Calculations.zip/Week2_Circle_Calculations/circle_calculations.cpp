// Assignment 2

#include <iostream>
#include <cmath>
#include <iomanip>

// Using std
using namespace std;

//Main Function 

int main() {

    // Const section
    const double PI = 3.14159265359;

    // Variable section
    double radius;
    double area;
    double circumference;
    double angle;
    double arcLength;

    // Input section
    cout << "Enter the radius of the circle: ";
    cin >> radius;

    cout << "Enter the central angle (in degrees): ";
    cin >> angle;

    // Process section
    area = PI * pow(radius, 2);
    circumference = 2 * PI * radius;
    arcLength = (angle / 360) * 2 * PI * radius;

    // Output section
    cout << fixed << setprecision(2);
    cout << "The area of the circle is: " << area << endl;
    cout << "The circumference of the circle is: " << circumference << endl;
    cout << "The arc length of the circle is: " << arcLength << endl;

    return 0;
}